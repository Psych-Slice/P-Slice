Here you can put all data files for P-Slice.
As of 2.2.2 this includes:
- Playable characters
- Albums
- Freeplay styles
