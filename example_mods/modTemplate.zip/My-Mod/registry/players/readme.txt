Put here data for playable characters.
