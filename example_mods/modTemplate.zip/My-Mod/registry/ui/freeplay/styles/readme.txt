Put here data for your freeplay styles used by playable characters.
